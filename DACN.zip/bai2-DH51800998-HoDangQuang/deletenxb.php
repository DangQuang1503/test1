<?php
include './config.php';
include './pdo.php';
$ma= isset($_GET['dh51802374_manxb'])?$_GET['dh51802374_manxb']:'';

if($ma!='')
{
    $sql= "delete from nhaxb where manxb= ? ";
    $a = [$ma];
    $stm = $objPDO->prepare($sql);
    $stm->execute($a);
}

header('location:content_boxnxb.php');
