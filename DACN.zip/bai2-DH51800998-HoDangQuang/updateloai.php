<?php 
include './pdo.php';
include './config.php';
$tenloai = isset($_POST['DH51800998_tenloai'])?$_POST['DH51800998_tenloai']:'';
$maloai = isset($_POST['DH51800998_maloai'])?$_POST['DH51800998_maloai']:'';


$sql="update loai set tenloai=? where maloai=?"  ;
$a =[ $tenloai,$maloai];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van
$n = $objStatement->rowCount();
//  echo "<pre>Da them $n dong";
//  echo $sql ;
// print_r($a);
header('location:content_boxloai.php');