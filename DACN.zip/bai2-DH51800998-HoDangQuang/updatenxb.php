<?php 
include './pdo.php';
include './config.php';
$tennxb = isset($_POST['DH51800998_tennxb'])?$_POST['DH51800998_tennxb']:'';
$manxb = isset($_POST['DH51800998_manxb'])?$_POST['DH51800998_manxb']:'';


$sql="update nhaxb set tennxb=? where manxb=?"  ;
$a =[$tennxb,$manxb];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van
$n = $objStatement->rowCount();
//  echo "<pre>Da them $n dong";
//  echo $sql ;
// print_r($a);
header('location:content_boxnxb.php');