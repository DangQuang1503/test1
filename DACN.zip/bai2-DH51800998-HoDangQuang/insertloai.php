<?php 
include './pdo.php';
include_once './config.php';

$maloai = isset($_POST['DH51800998_maloai'])?$_POST['DH51800998_maloai']:'';
$tenloai = isset($_POST['DH51800998_tenloai'])?$_POST['DH51800998_tenloai']:'';



$sql="insert into loai(maloai,tenloai) 
                    values(?, ?) ";
$a =[$maloai, $tenloai];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van

// echo "<pre>Da them $n dong";
// echo $sql ;

header('location:content_boxloai.php');