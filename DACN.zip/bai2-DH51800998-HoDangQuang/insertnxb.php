<?php 
include './pdo.php';
include_once './config.php';

$manxb = isset($_POST['DH51800998_manxb'])?$_POST['DH51800998_manxb']:'';
$tennxb = isset($_POST['DH51800998_tennxb'])?$_POST['DH51800998_tennxb']:'';



$sql="insert into nhaxb(manxb,tennxb) 
                    values(?, ?) ";
$a =[$manxb, $tennxb];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van

// echo "<pre>Da them $n dong";
// echo $sql ;

header('location:content_boxnxb.php');