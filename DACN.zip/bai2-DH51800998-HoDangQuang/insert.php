<?php 
include './pdo.php';
include_once './config.php';
$m = isset($_POST['DH51800998_masach'])?$_POST['DH51800998_masach']:'';
$t = isset($_POST['DH51800998_tensach'])?$_POST['DH51800998_tensach']:'';
$g = isset($_POST['DH51800998_gia'])?$_POST['DH51800998_gia']:0;
$maloai = isset($_POST['DH51800998_maloai'])?$_POST['DH51800998_maloai']:'th';
$mt = isset($_POST['DH51800998_mota'])?$_POST['DH51800998_mota']:'';
$manxb=isset($_POST['DH51800998_manxb'])?$_POST['DH51800998_manxb']:'gd';
$h ='';
if ($m==''){ header('location:index.php'); exit;}
if (isset($_FILES['DH51800998_hinh']))
{
    if ($_FILES['DH51800998_hinh']['error']==0) //ok
    {
        $h = $_FILES['DH51800998_hinh']['name'];
        move_uploaded_file($_FILES['DH51800998_hinh']['tmp_name'], "img/product/$h");
    }
}

$sql="insert into sach(masach, tensach, gia, hinh, mota, manxb, maloai) 
                    values(?, ?, ?, ?, ?, ?, ?) ";
$a =[$m, $t, $g, $h, $mt, $manxb, $maloai];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van

// echo "<pre>Da them $n dong";
// echo $sql ;

header('location:index.php');