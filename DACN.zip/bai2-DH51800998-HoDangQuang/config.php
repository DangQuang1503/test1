<?php 
define('HOST','localhost');
define('DB', 'bansach');
define('USER', 'root');
define('PW', '');
