<?php 
//$action = isset($_GET['action'])?$_GET['action']:'index';
$action= Utilities::get('action', 'all');
$sach = new Sach();
if ($action=='index')
{
    //hien thi
    $dataSach = $sach->random(10);//load data from model
    include './view/sach/index.php';

}
if ($action=='all')
{
    //hien thi
    $dataSach = $sach->getall();//load data from model
    include './view/sach/index.php';
}

if ($action=='search')
{
    $kw = Utilities::get('kw');
    //hien thi
    $dataSach = $sach->search($kw);//load data from model
    include './view/sach/index.php';

}
if ($action=='detail')
{
    //hien thi :'hung'  :' hung' ' hung    '-> trim
    //$masach= isset($_GET['masach'])?$_GET['masach']:'';
    $masach = Utilities::get('masach');
    $dataSach = $sach->getById($masach);//load data from model
    include './view/sach/detail.php';

}
if ($action=='insert')
{
    
    include './view/sach/insert.php';
}

if ($action=='store')
{
    //thuc hien them
}