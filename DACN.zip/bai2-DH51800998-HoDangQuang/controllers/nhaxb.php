<?php 
//$action = isset($_GET['action'])?$_GET['action']:'index';
$action= Utilities::get('action', 'all');
$nhaxb = new Nhaxb();
if ($action=='index')
{
    //hien thi
    $dataNhaxb = $nhaxb->random(10);//load data from model
    include './view/nhaxb/index.php';

}
if ($action=='all')
{
    //hien thi
    $dataNhaxb = $nhaxb->getall();//load data from model
    include './view/nhaxb/index.php';

}

if ($action=='search')
{
    $kw = Utilities::get('kw');
    //hien thi
    $dataNhaxb = $nhaxb->search($kw);//load data from model
    include './view/nhaxb/index.php';

}
if ($action=='detail')
{
    //hien thi :'hung'  :' hung' ' hung    '-> trim
    //$masach= isset($_GET['masach'])?$_GET['masach']:'';
    $manxb = Utilities::get('manxb');
    $dataNhaxb = $nhaxb->getById($manxb);//load data from model
    include './view/nhaxb/detail.php';

}
if ($action=='insert')
{
    include './view/nhaxb/insert.php';
}

if ($action=='store')
{
    //thuc hien them
}