<?php 
//$action = isset($_GET['action'])?$_GET['action']:'index';
$action= Utilities::get('action', 'all');
$loai = new Loai();
if ($action=='index')
{
    //hien thi
    $dataLoai = $loai->random(10);//load data from model
    include './view/loai/index.php';

}
if ($action=='all')
{
    //hien thi
    $dataLoai = $loai->getall();//load data from model
    include './view/loai/index.php';

}

if ($action=='search')
{
    $kw = Utilities::get('kw');
    //hien thi
    $dataLoai = $loai->search($kw);//load data from model
    include './view/loai/index.php';

}
if ($action=='detail')
{
    //hien thi :'hung'  :' hung' ' hung    '-> trim
    //$masach= isset($_GET['masach'])?$_GET['masach']:'';
    $maloai = Utilities::get('maloai');
    $dataLoai = $loai->getById($maloai);//load data from model
    include './view/loai/detail.php';

}
if ($action=='insert')
{
    include './view/loai/insert.php';
}

if ($action=='store')
{
    //thuc hien them
}