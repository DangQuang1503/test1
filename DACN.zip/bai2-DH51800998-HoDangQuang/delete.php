<?php
include './config.php';
include './pdo.php';
$ma= isset($_GET['masach'])?$_GET['masach']:'';

if($ma!='')
{
    $sql= "delete from sach where masach= ? ";
    $a = [$ma];
    $stm = $objPDO->prepare($sql);
    $stm->execute($a);
}
header('location:index.php');
