<?php 
include './pdo.php';
include './config.php';
$m = isset($_POST['DH51800998_masach'])?$_POST['DH51800998_masach']:'';
$t = isset($_POST['DH51800998_tensach'])?$_POST['DH51800998_tensach']:'';
$g = isset($_POST['DH51800998_gia'])?$_POST['DH51800998_gia']:0;
$maloai = isset($_POST['DH51800998_maloai'])?$_POST['DH51800998_maloai']:'th';
$mt = isset($_POST['DH51800998_mota'])?$_POST['DH51800998_mota']:'';
$manxb=isset($_POST['DH51800998_manxb'])?$_POST['DH51800998_manxb']:'gd';

$sql="update sach set tensach=?, gia=?, mota=?, manxb=?, maloai=?  where masach=?  ";
$a =[ $t, $g,  $mt, $manxb, $maloai, $m];
$objStatement= $objPDO->prepare($sql);//return B
$objStatement->execute($a);//ket qua truy van
$n = $objStatement->rowCount();
//  echo "<pre>Da them $n dong";
//  echo $sql ;
// print_r($a);
header('location:index.php');