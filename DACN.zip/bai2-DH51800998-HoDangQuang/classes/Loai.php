<?php 
if (!defined('HOST')) {exit;}
class Loai extends Db 
{
    function getAll()
    {
        return $this->selectQuery('select * from loai');
    }
    

    function getById($maloai)
    {
        return $this->selectQuery('select * from loai where maloai=?', [$maloai]);
    }
    function store($sql, $arr)
    {
        $this->updateQuery($sql, $arr);
    }

    function search($kw)
    {
        $sql ="select * from loai where tenloai like ?";
        $arr =["%$kw%"];
        return $this->selectQuery($sql, $arr);
    }
}
