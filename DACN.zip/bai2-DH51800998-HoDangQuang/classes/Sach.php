<?php 
if (!defined('HOST')) {exit;}
class Sach extends Db 
{
    function getAll()
    {
        return $this->selectQuery('select * from sach');
    }
    

    function getById($masach)
    {
        return $this->selectQuery('select * from sach where masach=?', [$masach]);
    }
    function store($sql, $arr)
    {
        $this->updateQuery($sql, $arr);
    }

    function search($kw)
    {
        $sql ="SELECT * from sach where tensach like ?";
        $arr =["%$kw%"];
        return $this->selectQuery($sql, $arr);
    }

    function getLoai()
    {
        return $this->selectQuery('select * from loai');
    }

    function getNxb()
    {
        return $this->selectQuery('select * from nhaxb');
    }

}
