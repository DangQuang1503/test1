<?php 
if (!defined('HOST')) {exit;}
class Nhaxb extends Db 
{
    function getAll()
    {
        return $this->selectQuery('select * from nhaxb');
    }
    

    function getById($manxb)
    {
        return $this->selectQuery('select * from nhaxb where manxb=?', [$manxb]);
    }
    function store($sql, $arr)
    {
        $this->updateQuery($sql, $arr);
    }

    function search($kw)
    {
        $sql ="select * from nhaxb where tennxb like ?";
        $arr =["%$kw%"];
        return $this->selectQuery($sql, $arr);
    }
}
