<?php
include './config.php';
include './pdo.php';
$ma= isset($_GET['dh51802374_maloai'])?$_GET['dh51802374_maloai']:'';

if($ma!='')
{
    $sql= "delete from loai where maloai= ? ";
    $a = [$ma];
    $stm = $objPDO->prepare($sql);
    $stm->execute($a);
}

header('location:content_boxloai.php');
